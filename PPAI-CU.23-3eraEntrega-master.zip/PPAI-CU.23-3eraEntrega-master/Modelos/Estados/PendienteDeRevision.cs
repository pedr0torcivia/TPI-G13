﻿namespace PPAI_Revisiones.Modelos.Estados
{
    public sealed class PendienteDeRevision : Estado
    {
        public override string Nombre => "PendienteDeRevision";
    }
}
