﻿namespace PPAI_Revisiones.Modelos.Estados
{
    public sealed class PendienteDeCierre: Estado
    {
        public override string Nombre => "PendienteDeCierre";
    }
}
