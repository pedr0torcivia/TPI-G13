﻿namespace PPAI_Revisiones.Modelos.Estados
{
    public sealed class Cerrado : Estado
    {
        public override string Nombre => "Cerrado";
        // Estado final: sin transiciones adicionales
    }
}
