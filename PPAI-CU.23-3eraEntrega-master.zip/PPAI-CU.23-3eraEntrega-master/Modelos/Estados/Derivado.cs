﻿namespace PPAI_Revisiones.Modelos.Estados
{
    public sealed class Derivado : Estado
    {
        public override string Nombre => "Derivado";
    }
}
