﻿namespace PPAI_Revisiones.Modelos.Estados
{
    public sealed class Autoconfirmado : Estado
    {
        public override string Nombre => "Autoconfirmado";
    }
}
